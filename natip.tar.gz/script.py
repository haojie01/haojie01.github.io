import socket
import time

def start_server(host="0.0.0.0", port=12345, timeout=1):
    while True:  # 无限循环，程序每次重启
        # 创建一个 TCP/IP 套接字
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            # 设置 SO_REUSEADDR 选项，允许端口重用
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind((host, port))
            s.listen(5)  # 设置最大连接等待队列
            print(f"Listening on {host}:{port}...")

            # 等待客户端连接
            conn, addr = s.accept()
            start_time = time.time()  # 记录连接开始的时间
            print(f"Connected by {addr}")

            # 为连接设置超时时间（socket 超时不会影响整个程序计时）
            conn.settimeout(1)  # 每次recv等待1秒，避免长时间阻塞

            with conn:
                # 向客户端返回其 IP 地址和端口
                conn.sendall(f"{addr[0]}:{addr[1]}\n".encode())

                # 保持连接，等待客户端关闭连接或达到超时时间
                while True:
                    elapsed_time = time.time() - start_time
                    if elapsed_time > timeout:  # 检查是否超过130秒
                        print(f"{timeout} seconds passed. Restarting server...")
                        break
                    #except socket.timeout:
                        # 每秒检查一下是否超时
                     #   continue

            # 连接结束，重新启动服务器
            print("Restarting server...")

if __name__ == "__main__":
    try:
        start_server()
    except KeyboardInterrupt:
        print("\nServer shutting down...")
