#!/bin/bash
if [ -f "$1" ]
then
        file=${1##*/}
        if ! [ -h "/var/www/html/sharefile/$file" ]
        then
                ln -s "$(pwd)/$1" "/var/www/html/sharefile/$file"
        fi
        url=$(cat $HOME/ipnat.txt)
        status_code=$(curl -o /dev/null -s -w "%{http_code}\n" --connect-timeout 1 -m 3 "$url")
        if [ "$status_code" -eq 200 ]
        then
                wz=http://$url/sharefile/$file
                wz=${wz//" "/"%20"}
                echo 临时地址: $wz
                wz=https://yourname.github.io?path=sharefile/$file
                wz=${wz//" "/"%20"}
                echo 永久地址: $wz
        else
                echo 地址获取失败
        fi
fi

