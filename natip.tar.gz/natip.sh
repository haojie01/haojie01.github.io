#!/bin/bash

outfile=ipnat.txt
port=54321
outport=80

while :
do
        if [ x:$url == x: ]; then
                status_code=0
        else
                status_code=$(curl -o /dev/null -s -w "%{http_code}\n" --connect-timeout 10 -m 30 "$url")
        fi
        if [ "$status_code" -eq 200 ]; then
                wget $url -O /dev/null
                sleep 3
        else
                sudo iptables -t nat -D PREROUTING -p tcp --dport $port -j REDIRECT --to-port $outport
		nc -p $port haojie.ip-dynamic.org 12345 |tee $outfile &
                sleep 1
                url=$(cat $outfile)
                sudo iptables -t nat -A PREROUTING -p tcp --dport $port -j REDIRECT --to-port $outport
		pkill -f -9 "nc -p $port"
        fi
done
