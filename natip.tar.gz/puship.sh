in=ipnat.txt
out=yourname.github.io/ipnat.txt
while :
do
        cd
        new=$(cat $in)
        old=$(cat $out)
        if [ i:"$new" != i:"$old" ]
        then
                cp $in $out
                cd yourname.github.io
                git add --all
		git commit -m "$(date)"
		git pull
		git add --all
		git commit -m "$(date)"
		git push
        fi
        sleep 300
done
